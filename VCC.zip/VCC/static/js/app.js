document.addEventListener('DOMContentLoaded', () => {
    const citySelect = document.getElementById('citySelect');
    const themeToggle = document.getElementById('themeToggle');
    const alertBanner = document.getElementById('alertBanner');
    const closeAlert = document.querySelector('.close-alert');
    
    // Theme toggle functionality
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        // Update charts with new theme colors
        updateData();
    });

    // Load saved theme
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
    }

    // Close alert banner
    closeAlert.addEventListener('click', () => {
        alertBanner.classList.add('hidden');
    });

    // Show weather alert
    function showAlert(message) {
        const alertMessage = document.querySelector('.alert-message');
        alertMessage.textContent = message;
        alertBanner.classList.remove('hidden');
    }

    // Get theme-based colors
    function getThemeColors() {
        return {
            primary: getComputedStyle(document.body).getPropertyValue('--primary-color'),
            text: getComputedStyle(document.body).getPropertyValue('--text-color'),
            background: getComputedStyle(document.body).getPropertyValue('--background-color'),
            border: getComputedStyle(document.body).getPropertyValue('--border-color')
        };
    }

    // Fetch current weather and create gauge charts
    async function fetchCurrentWeather(city) {
        try {
            const response = await fetch(`/api/weather/${city}`);
            const data = await response.json();
            
            const weatherInfo = document.querySelector('.weather-info');
            weatherInfo.innerHTML = `
                <p class="temperature">${Math.round(data.temperature)}°C</p>
                <p class="description">${data.description}</p>
                <div id="humidityGauge" class="gauge-chart"></div>
                <div id="windGauge" class="gauge-chart"></div>
            `;

            // Create humidity gauge
            const humidityGauge = {
                type: "indicator",
                mode: "gauge+number",
                value: data.humidity,
                title: { text: "Humidity %" },
                gauge: {
                    axis: { range: [0, 100] },
                    bar: { color: getThemeColors().primary },
                    bgcolor: getThemeColors().background,
                    borderwidth: 2,
                    bordercolor: getThemeColors().border,
                    steps: [
                        { range: [0, 30], color: "#B4E1FF" },
                        { range: [30, 70], color: "#82CFFF" },
                        { range: [70, 100], color: "#1E90FF" }
                    ]
                }
            };

            // Create wind speed gauge
            const windGauge = {
                type: "indicator",
                mode: "gauge+number",
                value: data.wind_speed,
                title: { text: "Wind Speed (m/s)" },
                gauge: {
                    axis: { range: [0, 20] },
                    bar: { color: getThemeColors().primary },
                    bgcolor: getThemeColors().background,
                    borderwidth: 2,
                    bordercolor: getThemeColors().border,
                    steps: [
                        { range: [0, 5], color: "#B4FFB4" },
                        { range: [5, 10], color: "#82FF82" },
                        { range: [10, 20], color: "#1E901E" }
                    ]
                }
            };

            const gaugeLayout = {
                width: 200,
                height: 150,
                paper_bgcolor: 'transparent',
                font: { color: getThemeColors().text }
            };

            Plotly.newPlot('humidityGauge', [humidityGauge], gaugeLayout);
            Plotly.newPlot('windGauge', [windGauge], gaugeLayout);

            // Show alert for severe weather conditions
            if (data.temperature > 35) {
                showAlert('Heat wave alert! Stay hydrated and avoid direct sun exposure.');
            } else if (data.description.includes('rain') || data.description.includes('storm')) {
                showAlert('Severe weather alert! Take necessary precautions.');
            }
        } catch (error) {
            console.error('Error fetching current weather:', error);
        }
    }

    // Fetch and display forecast with enhanced visualization
    async function fetchForecast(city) {
        try {
            const response = await fetch(`/api/forecast/${city}`);
            const data = await response.json();

            const timestamps = data.map(item => item.timestamp);
            const temperatures = data.map(item => item.temperature);
            const humidity = data.map(item => item.humidity);

            const traces = [
                {
                    x: timestamps,
                    y: temperatures,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Temperature (°C)',
                    line: {
                        color: getThemeColors().primary,
                        width: 3
                    },
                    marker: {
                        size: 8
                    }
                },
                {
                    x: timestamps,
                    y: humidity,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Humidity (%)',
                    yaxis: 'y2',
                    line: {
                        color: '#1E90FF',
                        width: 2,
                        dash: 'dot'
                    },
                    marker: {
                        size: 6
                    }
                }
            ];

            const layout = {
                title: '5-Day Forecast',
                paper_bgcolor: 'transparent',
                plot_bgcolor: 'transparent',
                font: {
                    color: getThemeColors().text
                },
                xaxis: {
                    gridcolor: getThemeColors().border,
                    title: 'Date & Time'
                },
                yaxis: {
                    gridcolor: getThemeColors().border,
                    title: 'Temperature (°C)',
                    titlefont: { color: getThemeColors().primary },
                    tickfont: { color: getThemeColors().primary }
                },
                yaxis2: {
                    title: 'Humidity (%)',
                    titlefont: { color: '#1E90FF' },
                    tickfont: { color: '#1E90FF' },
                    overlaying: 'y',
                    side: 'right',
                    gridcolor: getThemeColors().border
                },
                showlegend: true,
                legend: {
                    x: 0,
                    y: 1.2
                }
            };

            Plotly.newPlot('forecastChart', traces, layout);
        } catch (error) {
            console.error('Error fetching forecast:', error);
        }
    }

    // Fetch and display ML predictions with enhanced visualization
    async function fetchPredictions(city) {
        try {
            const response = await fetch(`/api/predictions/${city}`);
            const data = await response.json();

            const predictions = data.predictions;
            const dates = predictions.map(item => item.date);
            const temps = predictions.map(item => item.temperature);
            const upperBound = predictions.map(item => item.temperature_upper);
            const lowerBound = predictions.map(item => item.temperature_lower);
            const confidence = predictions.map(item => item.confidence_score);

            const traces = [
                {
                    x: dates,
                    y: temps,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Predicted Temperature',
                    line: {
                        color: getThemeColors().primary,
                        width: 3
                    },
                    marker: {
                        size: 8
                    }
                },
                {
                    x: dates.concat(dates.slice().reverse()),
                    y: upperBound.concat(lowerBound.slice().reverse()),
                    fill: 'toself',
                    fillcolor: 'rgba(0,176,246,0.2)',
                    line: { color: 'transparent' },
                    name: 'Prediction Interval',
                    showlegend: true
                },
                {
                    x: dates,
                    y: confidence,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Confidence Score (%)',
                    yaxis: 'y2',
                    line: {
                        color: '#FFD700',
                        width: 2,
                        dash: 'dot'
                    },
                    marker: {
                        size: 6
                    }
                }
            ];

            const layout = {
                title: {
                    text: 'ML-Based Temperature Predictions',
                    font: { size: 24 }
                },
                paper_bgcolor: 'transparent',
                plot_bgcolor: 'transparent',
                font: {
                    color: getThemeColors().text
                },
                xaxis: {
                    gridcolor: getThemeColors().border,
                    title: 'Date'
                },
                yaxis: {
                    gridcolor: getThemeColors().border,
                    title: 'Temperature (°C)',
                    titlefont: { color: getThemeColors().primary },
                    tickfont: { color: getThemeColors().primary }
                },
                yaxis2: {
                    title: 'Confidence Score (%)',
                    titlefont: { color: '#FFD700' },
                    tickfont: { color: '#FFD700' },
                    overlaying: 'y',
                    side: 'right',
                    range: [0, 100],
                    gridcolor: getThemeColors().border
                },
                showlegend: true,
                legend: {
                    x: 0,
                    y: 1.2
                },
                annotations: [{
                    x: 0,
                    y: 1.12,
                    xref: 'paper',
                    yref: 'paper',
                    text: `Model Accuracy: ${data.model_info.confidence_score}% | MAE: ${data.model_info.mean_absolute_error}°C`,
                    showarrow: false,
                    font: {
                        size: 12
                    }
                }]
            };

            Plotly.newPlot('predictionsChart', traces, layout);
        } catch (error) {
            console.error('Error fetching predictions:', error);
        }
    }

    // Fetch and display recommendations
    async function fetchRecommendations() {
        try {
            const response = await fetch('/api/recommendations');
            const data = await response.json();

            const recommendationsList = document.querySelector('.recommendations-list');
            recommendationsList.innerHTML = data.map(item => `
                <li>
                    <strong>${item.city}</strong><br>
                    ${item.reason}
                </li>
            `).join('');
        } catch (error) {
            console.error('Error fetching recommendations:', error);
        }
    }

    // Update all data when city changes
    function updateData() {
        const selectedCity = citySelect.value;
        fetchCurrentWeather(selectedCity);
        fetchForecast(selectedCity);
        fetchPredictions(selectedCity);
        fetchRecommendations();
    }

    // Initial data load
    updateData();

    // Update data when city changes
    citySelect.addEventListener('change', updateData);

    // Update data every 5 minutes
    setInterval(updateData, 5 * 60 * 1000);
}); 